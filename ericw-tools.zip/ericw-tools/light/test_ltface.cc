#include "gtest/gtest.h"

#include <light/ltface.hh>
