### TODOs ###
- [x] Fix compatbility issues with Blender 6.8
- [x] Make a palette picker menu when importing/exporting
- [x] Fix eye position scaling
- [x] Add support for Hexen II flags
- [ ] Add support for custom palettes
- [ ] Add support for boilerplate QuakeC
- [ ] Refactor code for speed

