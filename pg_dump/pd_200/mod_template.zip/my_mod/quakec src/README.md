# progs_dump_qc
This is the most current version of progs_dump .qc source.

Then latest official release is version 1.1.2.1 which can be downloaded here:
http://www.quaketastic.com/files/single_player/mods/progs_dump_devkit_v1121.zip
